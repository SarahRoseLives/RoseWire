<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

$author = ossn_user_by_guid($params['item']->owner_guid);
?>
<div class="row blog-item">
	<div class="col-md-12">
    		<a href="<?php echo $params['item']->profileURL();?>"><?php echo $params['item']->title;?>&nbsp;&nbsp;<i style="font-weight:normal; font-size:smaller"><?php echo ossn_print('com:blog:blog:edit:timestamp' , array(date(ossn_print('com:blog:blog:edit:timestamp:format'), $params['item']->time_created))); ?>&nbsp;&nbsp;<?php echo ossn_print('com:blog:list:by:author:', array($author->fullname)); ?></i></a> 
    </div>
</div>